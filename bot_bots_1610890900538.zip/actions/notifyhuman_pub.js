  //const { PubSub } = require('@google-cloud/pubsub');
  /**
   * Small description of your action
   * @title Notifies the agent of a user who wants to speak to them
   * @category Notification
   * @author apmurali
   * @param {string} name - User name
   * @param {any} value - Another Example value
   */

  const myAction = async (name, value) => {
    const topicName = 'agentnotifications'
    const message = 'The user ' + name + ' wants to chat with you. '
    x = Math.floor(Math.random() * (2147483647 - 0)) //max safe integer. very ugly workaround :|
    bp.notifications.create('etabot', {
      botId: 'etabot',
      //id: x,
      message: message,
      level: 'info',
      redirectUrl: '/modules/hitl'
    })
  }

  return myAction(args.name, args.value)