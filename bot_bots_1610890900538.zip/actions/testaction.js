const { PubSub } = require('@google-cloud/pubsub')

  /**
   * Small description of your action
   * @title The title displayed in the flow editor
   * @category Category
   * @author Your_Name
   * @param {string} name - An example string variable
   * @param {any} value - Another Example value
   */
  const myAction = async (name, value) => {
    const pubsub = new PubSub();

    /**
     * TODO(developer): Uncomment the following lines to run the sample.
     */
    const topicName = 'agentnotifications';
    const data = JSON.stringify({ message: 'hallo from ubuntu' });

    // Publishes the message as a string, e.g. "Hello, world!" or JSON.stringify(someObject)
    const dataBuffer = Buffer.from(data);

    const messageId = pubsub.topic(topicName).publish(dataBuffer);
    console.log(`Message ${messageId} published.`);


  }

  return myAction(args.name, args.value)