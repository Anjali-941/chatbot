/**
   * Small description of your action
   * @title Increment no of tries
   * @category Category
   * @author Your_Name
   * @param {string} name - An example string variable
   * @param {any} value - Another Example value
   */
  const incrementTries = async (value) => {
    if (value === undefined) {
      value = 0;
    } else {
      value++;
    }
    temp.tries = value


  }

  return incrementTries(args.value)