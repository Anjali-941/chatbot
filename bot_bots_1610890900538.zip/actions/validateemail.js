/**
       * Small description of your action
       * @title Validate email withou NLU
       * @category Category
       * @author apmurali
       * @param {string} name - An example string variable
       * @param {any} value - Another Example value
       */
  const mailValidator = async (email) => {
    const userInput = email.toString()
    var regexp = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

    //const matchAllOccurences = userInput.matchAll(regexp);

    //const occurrencesArray = Array.from(matchAllOccurences); // array now
    temp.valid = regexp.test(userInput)
    console.log(temp.valid)

  }

  return mailValidator(args.email)