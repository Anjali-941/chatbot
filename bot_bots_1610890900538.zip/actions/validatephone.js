const PhoneNumber = require('awesome-phonenumber');

  /**
   * Small description of your action
   * @title The title displayed in the flow editor
   * @category Category
   * @author Your_Name
   * @param {string} name - An example string variable
   * @param {any} value - Another Example value
   */
  const myAction = async (name, value) => {
    const pn = new PhoneNumber(value)
    temp.pnvalid = pn.isValid();
    console.log(temp.pnvalid)

  }

  return myAction(args.name, args.value)