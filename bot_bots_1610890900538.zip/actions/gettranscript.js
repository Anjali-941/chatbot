  const axios = require('axios')
  /**
   * Small description of your action
   * @title Get transcript
   * @category User defined
   * @author Aparajitha
   * @param {string} userID - User ID of current user, available as {{event.target}}
   * @param {string} conversationID - Conversation ID available as {{event.threadId}}
   */
  const myAction = async (userId, conversationId) => {
    //console.log(event.threadId)
    //console.log(event.target)
    const { data } = await axios.get(
      'http://localhost:3000/api/v1/bots/etabot/mod/channel-web/conversations/' +
        event.target +
        '/' +
        event.threadId +
        '/download/txt'
    )

    var textedited = data
    //console.log(data)

    //console.log(textedited['txt'])
    console.log(textedited)
    var brokentext = textedited['txt'].replace(/(\r\n|\n|\r)/gm, '\t\n\t\n  ')
    //textedited = textedited.replace(/(\r\n|\n|\r)/gm, '\n')
    //console.log(textedited.txt)
    session.transcript = brokentext
  }

  return myAction(args.userId, args.conversationId)