const { PubSub } = require('@google-cloud/pubsub');
  /**
           * Small description of your action
           * @title Notifies the agent of a user who wants to speak to them
           * @category Notification
           * @author apmurali
           * @param {string} name - User name
           * @param {any} value - Another Example value
           */


  const myAction = async (name, value) => {
    //const {PubSub} = require('@google-cloud/pubsub');
    const topicName = 'agentnotifications';
    const message = 'The user ' + name + ' wants to chat with you. '
    bp.notifications.create('etabot', { botId: 'etabot', message: message, level: 'info', redirectUrl: '/modules/hitl' })
    // Creates a client
    const pubsub = new PubSub();

    /**
     * TODO(developer): Uncomment the following lines to run the sample.
     */
    //const topicName = 'agentnotifications';
    const data = JSON.stringify({ message: 'The user ' + name + ' wants to chat with you. ' });

    // Publishes the message as a string, e.g. "Hello, world!" or JSON.stringify(someObject)
    const dataBuffer = Buffer.from(data);

    const messageId = pubsub.topic(topicName).publish(dataBuffer);
    console.log(`Message ${messageId} published.`);

  }

  return myAction(args.name, args.value)