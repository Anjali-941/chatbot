  /**
   * Small description of your action
   * @title Rename conversations in HITL
   * @category User Defined
   * @author Aparajitha
   * @param {string} name - An example string variable
   * @param {any} value - Another Example value
   */
  const myAction = async (name, value) => {
    const m = bp
      .database('hitl_sessions')
      .select('hitl_sessions.full_name as name', 'hitl_sessions.userId', 'hitl_sessions.id')
      .where('userId', event.target)
      //the following line will be used to print the query. any other method returns a promise object aka gibberish
      .then(data => data.forEach(renameConvoUserFriendly)) // the knex query (check documentation) will return a list of dictionaies containing all the results

    //this function will rename the HITL username from the long numeric abomination that it is right now
    //to that given by the user so that it is easier to locate
    function renameConvoUserFriendly(item) {
      console.log('value of the item', item)
      console.log(('000000' + item.id).slice(-6)) // append zeroes to the pk (id) of the HITL session for the current user
      console.log(user.nickname + '_' + ('000000' + item.id).slice(-6))
      var newname = user.nickname + '_' + ('000000' + item.id).slice(-6)
      bp.database('hitl_sessions')
        .where({ userId: event.target, id: item.id })
        .update({ full_name: newname })
        .then(data => console.log(data))
    }
    //.then(something => console.log(something))
    console.log('whats this?', m)
    //console.log(m)
  }

  //console.log(m.toString())
  //console.log(event.target)

  return myAction(args.name, args.value)